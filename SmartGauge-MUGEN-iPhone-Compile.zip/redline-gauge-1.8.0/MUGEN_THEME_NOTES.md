# MUGEN-inspired theme modification

This archive adds a fourth selectable red/black racing theme named `MUGEN` (`theme=mugen`).
The theme is inspired by Japanese touring/racing dashboards; it does not include an official
MUGEN logo or claim affiliation with MUGEN.

## What changed
- Added `src/assets/bg_mugen.h` and `tools/art/bg_mugen.png` using the existing REDLINE gauge artwork geometry with red accent lighting.
- Added the MUGEN palette to `src/ui/theme.cpp` and the theme enum to `src/ui/theme.h`.
- Expanded the theme selector to four compact cards.
- Set MUGEN as the default for a fresh settings store; previously saved NVS theme selections are retained.
- Added the `theme=mugen` serial command and updated documentation.
- RPM, speed, gear, OBD, serial data, warnings, shift light and existing splash credit logic are otherwise unchanged.

## Hardware/build note
The supplied REDLINE 1.8.0 project is a TFT_eSPI project for the CYD ESP32-2432S028R, configured as
320x240 landscape. It is not an LVGL project and does not build as a 240x320 portrait layout without
additional display-layout and touch-coordinate work. Choose the matching panel inversion/SPI environment
from `platformio.ini` before flashing.

## Build
With PlatformIO installed and dependencies available:

```sh
pio run -e esp32dev-dim-spi40
```

Select another environment in `platformio.ini` if the panel needs a different inversion or SPI speed.

The upstream project is licensed PolyForm Noncommercial 1.0.0. See `LICENSE.md` and `NOTICE` before
redistributing or using commercially.
