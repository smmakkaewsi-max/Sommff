# คู่มือคอมไพล์ Smart Gauge MUGEN ด้วย iPhone

> ใช้ GitHub Codespaces ผ่าน Safari/Chrome ได้ ไม่ต้องติดตั้งโปรแกรมบน iPhone  
> หมายเหตุ: คู่มือนี้ช่วยคอมไพล์ “ซอร์สโค้ด” เท่านั้น ยังไม่ยืนยันว่าโค้ดมีระบบอ่าน/ลบ DTC ของ Honda Wave 125i ปี 2013 ที่ใช้งานจริงครบแล้ว และยังต้องตรวจวงจร K-Line/โปรโตคอล ECU ก่อนนำไปต่อรถ

## 1) อัปโหลดโปรเจกต์ขึ้น GitHub
1. เปิด https://github.com แล้วสมัคร/เข้าสู่ระบบ
2. กด **New repository** ตั้งชื่อ `wave-smart-gauge` และเลือก **Private** (แนะนำ)
3. แตกไฟล์ ZIP นี้ในแอป Files หรือคอมพิวเตอร์ แล้วอัปโหลดโฟลเดอร์/ไฟล์โปรเจกต์เข้า repository ให้เห็น `platformio.ini` ที่หน้าแรกของ repo
4. ถ้าใช้ iPhone อย่างเดียว: GitHub หน้าเว็บอาจอัปโหลดหลายไฟล์ยาก แนะนำเปิด **Request Desktop Website** ใน Safari หรือใช้ GitHub Codespaces “Upload files” ใน terminal

## 2) เปิด Codespaces
1. ในหน้า repo กดปุ่ม **Code** → **Codespaces** → **Create codespace on main**
2. รอหน้า VS Code บนเว็บโหลดเสร็จ
3. เปิด Terminal (เมนู Terminal → New Terminal)

## 3) ติดตั้ง PlatformIO และคอมไพล์
คัดลอกคำสั่งทีละบรรทัดใน Terminal:

```bash
python3 -m pip install --user platformio
export PATH="$HOME/.local/bin:$PATH"
pio --version
```

จากนั้นตรวจชื่อ environment:
```bash
grep -n '^\[env:' platformio.ini
```

เลือก environment ที่ตรงกับบอร์ด/จอของคุณ (อย่าเดาชื่อ) แล้วคอมไพล์ เช่น:
```bash
pio run -e esp32dev-dim-spi40
```
หาก environment ชื่อนี้ไม่มี ให้ใช้ชื่อที่แสดงจากคำสั่ง `grep` แทน

## 4) ดาวน์โหลดไฟล์ firmware.bin
เมื่อคอมไพล์ผ่าน ให้เปิด Terminal แล้วพิมพ์:
```bash
find .pio/build -name firmware.bin
```
ใน VS Code Explorer เปิดไฟล์ที่พบ (มักอยู่ใน `.pio/build/<ชื่อ-env>/firmware.bin`) แล้วกด Download หรือใช้เมนูไฟล์เพื่อดาวน์โหลดลง iPhone

## 5) แฟลชลง ESP32
ไฟล์ `.bin` ที่คอมไพล์จาก PlatformIO อาจต้องแฟลชพร้อม bootloader/partition/boot_app0 และ offset ที่ถูกต้องตามโปรเจกต์ ไม่ใช่ทุกกรณีที่แฟลช `firmware.bin` เดี่ยวได้
ใช้วิธีแฟลช/offset ตามเอกสาร Release ของโปรเจกต์ และตรวจบอร์ดให้ตรงรุ่นก่อนเสมอ

## แก้ปัญหาเบื้องต้น
- `pio: command not found` → รัน `export PATH="$HOME/.local/bin:$PATH"` อีกครั้ง
- หา `platformio.ini` ไม่เจอ → เปิด Terminal ที่ root repository
- build ล้ม → ส่งข้อความ error ใน Terminal มาให้ช่วยวิเคราะห์

## ข้อมูลฮาร์ดแวร์ที่ต้องยืนยันก่อนทำเฟิร์มแวร์รถ
- รุ่นบอร์ด ESP32/CYD และ pin TFT/Backlight
- วงจร K-Line (ชิป interface ที่ใช้ ไม่ต่อ K-Line เข้าขา ESP32 ตรงๆ)
- วิธีอ่าน/ลบ DTC ของ ECU Honda PGM-FI รุ่นปี 2013 และเงื่อนไขความปลอดภัย
